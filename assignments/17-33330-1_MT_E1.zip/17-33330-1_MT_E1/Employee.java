import java.lang.*;

public class Employee {
    private String id;
    private String name;
    private String designation;

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getDesignation() {
        return this.designation;
    }
}

